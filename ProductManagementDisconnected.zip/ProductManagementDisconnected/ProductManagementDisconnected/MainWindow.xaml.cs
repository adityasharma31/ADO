﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ProductManagementDisconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
        SqlCommand command = new SqlCommand();
        DataSet dataset = new DataSet();
        SqlDataAdapter adapter = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataRow newRow = dataset.Tables[0].NewRow();
                newRow[0] = txtProductId.Text;
                newRow[1] = txtProductName.Text;
                newRow[2] = txtPrice.Text;
                newRow[3] = txtQuantity.Text;
                dataset.Tables[0].Rows.Add(newRow);
                MessageBox.Show("Product Added to Dataset");
            }
            catch(SqlException exception)
            {
                MessageBox.Show("Exception Occured " + exception.Message);
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                command.CommandText = "Select * from Products_46023367";
                adapter = new SqlDataAdapter(command.CommandText, connection);
                adapter.Fill(dataset);
                dgProducts.DataContext = dataset.Tables[0];
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured " + exception.Message);
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            int productId = int.Parse(txtProductId.Text);
            for(int i=0;i<dataset.Tables[0].Rows.Count;i++)
            {
                int currentRowProductId=int.Parse(dataset.Tables[0].Rows[i][0].ToString());
                if(currentRowProductId==productId)
                {
                    MessageBox.Show("Product Found");
                    txtProductName.Text = dataset.Tables[0].Rows[i][1].ToString();
                    txtPrice.Text = dataset.Tables[0].Rows[i][2].ToString();
                    txtQuantity.Text = dataset.Tables[0].Rows[i][3].ToString();
                    break;
                }         
            }
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            int productId = int.Parse(txtProductId.Text);
            for (int i = 0; i < dataset.Tables[0].Rows.Count; i++)
            {
                int currentRowProductId = int.Parse(dataset.Tables[0].Rows[i][0].ToString());
                if (currentRowProductId == productId)
                {
                    dataset.Tables[0].Rows[i][1] = txtProductName.Text;
                    dataset.Tables[0].Rows[i][2] = txtPrice.Text;
                    dataset.Tables[0].Rows[i][3] = txtQuantity.Text;
                    MessageBox.Show("Product Updated to Dataset");
                    break;
                }
            }
        }

        private void WriteToDatabaseButton_Click(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
            adapter.Update(dataset);
            MessageBox.Show("All Changes Written to Database");
        }
    }
}
