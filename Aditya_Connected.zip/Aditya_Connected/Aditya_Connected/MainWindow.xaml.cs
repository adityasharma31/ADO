﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ProductManagementApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        SqlCommand command = new SqlCommand();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();   
                string productName = txtProductName.Text;
                float price = float.Parse(txtPrice.Text);
                int Quantity = int.Parse(txtQuantity.Text);
                command.CommandText = "Insert into Products_46023367 values('" + productName + "'," + price + "," + Quantity + ")";
                command.Connection = connection;
                int numberOfRowsAdded = command.ExecuteNonQuery();
                if (numberOfRowsAdded == 1)
                {
                    MessageBox.Show("Product Added Successfully");
                }
                else
                {
                    MessageBox.Show("Something Went Wrong!!!");
                }
            }
            catch(SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if(connection.State == ConnectionState.Open)
                    connection.Close();
            }
            LoadGrid();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetProductsCount();
            LoadGrid();
        }

        private void LoadGrid()
        {
            try
            {
                connection.Open();
                command.CommandText = "select * from Products_46023367";
                command.Connection = connection;
                SqlDataReader reader = command.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                dgProducts.DataContext = table;
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void GetProductsCount()
        {
            try
            {
                connection.Open();
                command.CommandText = "select count(ProductId) from Products_46023367";
                command.Connection = connection;
                int ProductCount =int.Parse(command.ExecuteScalar().ToString());
                MessageBox.Show(ProductCount+ "Products Found");
             
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void btndeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                command.CommandText = "Delete from Products_46023367 where  ProductId=" + int.Parse(txtProductId.Text);
                command.Connection = connection;
                int numberOfRowsDeleted = command.ExecuteNonQuery();
                if (numberOfRowsDeleted == 1)
                {
                    MessageBox.Show("Product Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Something Went Wrong!!!");
                }
                
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
            LoadGrid();
        }

        private void btnSearchProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                command.CommandText = "select * from Products_46023367 where ProductId="+int.Parse(txtProductId.Text);
                command.Connection = connection;
                SqlDataReader reader = command.ExecuteReader();
                while(reader.Read())
                {
                    txtProductName.Text = reader["ProductName"].ToString();
                    txtPrice.Text = reader["Price"].ToString();
                    txtQuantity.Text = reader["Quantity"].ToString();
                }
                
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void btnUpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.Open();
                string productName = txtProductName.Text;
                float price = float.Parse(txtPrice.Text);
                int Quantity = int.Parse(txtQuantity.Text);
                command.CommandText = "update Products_46023367 set ProductNAme='"+ productName + "',Price="+ price + ",Quantity="+ Quantity + " where ProductId="+int.Parse(txtProductId.Text);
                command.Connection = connection;
                int numberOfRowsAdded = command.ExecuteNonQuery();
                if (numberOfRowsAdded == 1)
                {
                    MessageBox.Show("Product Added Successfully");
                }
                else
                {
                    MessageBox.Show("Something Went Wrong!!!");
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured. Details are:" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
            LoadGrid();
        }

    }
    
}


