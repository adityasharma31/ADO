﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PMS_Entity;
using PMS_Exception;
using PMS_BLL;


namespace PMS_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            string productName = txtProductName.Text;
            float price = 0;
            if (txtPrice.Text != String.Empty)
                price = float.Parse(txtPrice.Text);
            int quantity = 0;
            if(txtQuantity.Text != String.Empty)
                quantity=int.Parse(txtQuantity.Text);

            Product newProduct = new Product();
            newProduct.ProductName = productName;
            newProduct.Price = price;
            newProduct.Quantity = quantity;
            PMSBLL bll = new PMSBLL();
            try
            {
                if (bll.AddProductBLL(newProduct))
                    MessageBox.Show("Product Added Successfully");
            }
            catch(ProductException exception)
            {
                MessageBox.Show("Exception Occured. "+exception.Message);
            }
        }
    }
}
