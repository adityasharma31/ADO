﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using PMS_Entity;
using PMS_Exception;

namespace PMS_DAL
{
    public class PMSDAL
    {
        SqlConnection connection = new SqlConnection(Config.ConnectionString);
        SqlCommand command = new SqlCommand();
        public bool AddProductDAL(Product newProduct)
        {
            bool isAddedProductDal = false;
            try
            {
                connection.Open();
                command.CommandText = "AddProduct_46023367";
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ProductName",newProduct.ProductName);
                command.Parameters.AddWithValue("@Price", newProduct.Price);
                command.Parameters.AddWithValue("@Quantity", newProduct.Quantity);

                SqlParameter outParameter = new SqlParameter();
                outParameter.ParameterName = "isAdded";
                outParameter.SqlDbType = SqlDbType.Int;
                outParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(outParameter);
                command.Connection = connection;
                command.ExecuteNonQuery();
                if (int.Parse(outParameter.Value.ToString()) == 1)
                {
                    isAddedProductDal = true;
                }
              
            }
            catch (SqlException exception)
            {
                throw new ProductException(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
            return isAddedProductDal;
        }
    }
}
