﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entity;
using PMS_Exception;
using PMS_DAL;

namespace PMS_BLL
{
    public class PMSBLL
    {
        PMSDAL dal = new PMSDAL();
        public bool AddProductBLL(Product newProduct)
        {
            bool isProductAdded = false;
            if(ValidateProduct(newProduct))
            {
                isProductAdded = dal.AddProductDAL(newProduct);
            }
            return isProductAdded;

        }
        public bool ValidateProduct(Product newProduct)
        {
            StringBuilder exceptionMessage = new StringBuilder();
            bool isProductValid = true;
            try
            {
                if (newProduct.ProductName == String.Empty || newProduct.ProductName == null)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid Product Name\n");
                }
                if (newProduct.Price <= 0)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid Price\n");
                }
                if (newProduct.Quantity <= 0)
                {
                    isProductValid = false;
                    exceptionMessage.Append("Invalid Quantity\n");
                }
                if(isProductValid==false)
                {
                    throw new ProductException(exceptionMessage.ToString());
                }      
            }
            catch(ProductException)
            {
                throw;
            }
            return isProductValid;
        }
    }
}
